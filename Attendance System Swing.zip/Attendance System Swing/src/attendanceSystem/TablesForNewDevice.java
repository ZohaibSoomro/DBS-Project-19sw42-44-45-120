package attendanceSystem;

public class TablesForNewDevice {

	public static void main(String[] args) {
		OracleConnection.createTables();
	}

}
