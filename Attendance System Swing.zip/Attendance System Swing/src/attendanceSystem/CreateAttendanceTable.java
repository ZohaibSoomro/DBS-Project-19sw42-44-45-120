package attendanceSystem;

public class CreateAttendanceTable {

	public static void main(String[] args) {
		OracleRelatedTasks.createAttendanceTable();
	}
}
